import tkinter as tk
from tkinter import ttk
import random

puppies =  ["Scrapper", "Snowy", "Tanner", "Hocus Pocus", "Daisy", "Scout", "Star", "Bodey", "Pebbles", "Johnson", "Triangle", "Nugget","Bramble","Brownie","Mini Doby","Custard","Cheerio","Aspen","Pickles","Pegstar","Orbit Round","Gunner", "Tucker", "Bone", "Barley", "Snowball", "Sparkie", "Dalmatian", "Golden Retriever", "Tom", "Sam", "Sky", "Star 2", "Pebbles 2", "Nugget 2", "Bramble 2", "Sky 2", "Jack", "Zack", "Max", "Candy", "Husky", "Mocca", "Airdale", "Ted", "Charles", "Smokey", "Ranger", "Fetcher",  "Coconut", "Fidget", "Beanie"]

blank = ["", ""]

def generate():
    random_puppy = random.choice(puppies)
    result_label.config(text=random_puppy)

def clear_res():
    random_puppy = random.choice(blank)
    result_label.config(text=random_puppy)

window = tk.Tk()
window.title("Random Puppy Generator for Windows XP")
window.geometry("400x400")
window.iconbitmap("icon.ico")

notebook = ttk.Notebook(window)
notebook.pack(pady=10, padx=10, expand=True, fill="both")

tab1 = ttk.Frame(notebook)
notebook.add(tab1, text="Generate Puppy")

# Add button to generate
button_generate = ttk.Button(tab1, text="Generate", command=generate)
button_generate.pack(padx=5)

# Add  button to clear
clear = ttk.Button(tab1, text="Clear", command=clear_res)
clear.pack(padx=5)

# Label time
result_label = tk.Label(tab1, text="", font=("Tahoma", 8))
result_label.pack(pady=5)

tab2 = ttk.Frame(notebook)
notebook.add(tab2, text="All Puppies")

puppy_list = tk.Text(tab2, wrap=tk.WORD, height=22, width=17, font=("Tahoma", 8))
puppy_list.pack(pady=22, padx=17)

for puppy in puppies:
    puppy_list.insert(tk.END, puppy + "\n")
window.mainloop()
